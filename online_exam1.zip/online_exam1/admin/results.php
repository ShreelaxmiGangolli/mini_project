<?php
session_start();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Online Quiz - View Result</title>
<link href="../quiz.css" rel="stylesheet" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="quiz.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<style>
    .table.table-striped{
        width:80%;
        margin:auto;
        border:1px solid #ddd;
    }
</style>
</head>
<body>
<?php
include("header.php");
include("../database.php");
{

		echo"<h1 class='text-center bg-danger'>RESULTS</h1>";
		echo "<table class='table table-striped'>";
		echo "<tr>
		<th  class='text-primary'>NAME</th>
				<th class='text-primary'>TEST NAME</th>
	<th class='text-primary'>SCORE</th></tr>";

	
	$query="select test_name,login,score from mst_result NATURAL join mst_test";
$result =mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
while($row=mysqli_fetch_assoc($result)){
    echo "<tr class='table-row' >
    <td > ".$row['login']."</td>
    <td  > ".$row['test_name']."</td>
    <td > ".$row['score']."</td>    </tr>";
    

}
		
}

?>



</body>
</html>








































<!-- 






















<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table class="table table-bordered">
        <thead>
        <tr>
        <th>NAME</th>
        <th>Test_ID</th>
        <th>Score</th>
        </tr>
        </thead>
    </table>
    <?php 
 
$con=mysqli_connect("localhost","root","","quiz_new") or die('Database not connected');


?>
    


 -->
