

<style type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<style>
.text-success .text-center .btn .btn-success{
width:100%;
}
.width{
	width:100%;
}
.left{
	display: flex;
    justify-content: space-between;
}
</style>
</style>
<table>
<tr>
    <td width="10%">
     <img border="0" src="h.jpg" width="100%" height="150" align="right"></td>
  </tr>

</table>
  <Table width="100%">
  <tr>
  <td>
  <?php @$_SESSION['login']; 
  error_reporting(1);
  ?>
  </td>
    <td>
	
<?php
	if(isset($_SESSION['alogin']))
	{
	
	 echo "<h4 class='text-success text-center btn btn-success width'>
	 <div class='left' align=\"left\"><strong>
	 <a href=\"viewsub.php\">  view Subject</a>&nbsp;&nbsp;
		<a href=\"testview.php\"> view Test</a>&nbsp;  &nbsp;
	 <a href=\"questiondelete.php\">View Question</a>&nbsp;&nbsp;
	 <a href=\"showuser.php\"> view user</a>&nbsp;&nbsp;
	 <a href=\"results.php\">view result</a></strong>
	 <strong><a href=\"login.php\">Admin Home</a>&nbsp;&nbsp;
	 <a href=\"signout.php\">Signout</a></strong>
	 </div></h4>";
	 }
	 else
	 {
	 	echo "&nbsp;";
	 }
	?>
		</td>
	
  </tr>
  
</table>
